package com.example.engine

import android.os.Handler
import android.os.Looper
import com.example.model.FpsConfig
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * Fake Engine: Generates realistic synthetic FPS with authentic micro-fluctuations,
 * real-time drop synchronization with the device's actual display/game frame rate,
 * and exact frame-time calculation without any arbitrary upper-bound limitations.
 */
class FakeFpsEngine {

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var config: FpsConfig = FpsConfig()

    private var onUpdateListener: ((fps: Float, frameTimeMs: Float, isDropping: Boolean) -> Unit)? = null

    // Real FPS link state
    @Volatile
    private var lastRealFps: Float = 60.0f
    @Volatile
    private var lastRealDropRatio: Float = 1.0f

    // Manual forced drop simulation state
    private var dropStartTimeMs: Long = 0L
    private var isDroppingActive = false
    private var dropStartTargetFps: Float = 120f
    private var dropFloorFps: Float = 48f

    // Natural wave counter for organic fluctuations
    private var waveStep = 0.0

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return

            val now = System.currentTimeMillis()
            var baseFps = config.targetFps
            var currentlyDropping = false

            // 1. Link with Real FPS drops if enabled
            if (config.syncWithRealFps) {
                val realRatio = lastRealDropRatio
                if (realRatio < 0.95f) {
                    currentlyDropping = true
                    // Apply sensitivity multiplier
                    val dropDepth = (1.0f - realRatio) * config.realDropSensitivity
                    val scaledRatio = (1.0f - dropDepth).coerceIn(0.08f, 1.0f)
                    baseFps = config.targetFps * scaledRatio
                }
            }

            // 2. Check if manual drop simulation is active
            if (isDroppingActive) {
                val elapsed = now - dropStartTimeMs
                val duration = config.dropDurationMs

                if (elapsed < duration) {
                    currentlyDropping = true
                    val progress = (elapsed.toDouble() / duration.toDouble()).coerceIn(0.0, 1.0)

                    // Physics curve: plunge then organic exponential recovery
                    val manualFloor = dropFloorFps.coerceAtMost(config.targetFps * 0.5f)
                    val dropBase = if (progress < 0.12) {
                        val plungeProgress = progress / 0.12
                        dropStartTargetFps - (dropStartTargetFps - manualFloor) * plungeProgress.toFloat()
                    } else {
                        val recoveryProgress = (progress - 0.12) / 0.88
                        val curve = (1.0 - exp(-3.2 * recoveryProgress)).toFloat().coerceIn(0f, 1f)
                        manualFloor + (config.targetFps - manualFloor) * curve
                    }
                    baseFps = minOf(baseFps, dropBase)
                } else {
                    isDroppingActive = false
                }
            }

            // 3. Apply Micro-fluctuations (Natural Jitter)
            var finalFps = baseFps
            if (config.jitterEnabled) {
                waveStep += 0.35 + Random.nextDouble(-0.05, 0.05)
                val organicWave = (sin(waveStep * 0.8) * 0.55 + cos(waveStep * 1.4) * 0.45).toFloat()
                val stochasticNoise = Random.nextFloat() * 0.4f - 0.2f
                
                // Scale jitter slightly with higher FPS targets so it feels natural even at 500-1000 FPS
                val scale = if (config.targetFps > 200f) (config.targetFps / 120f).coerceAtMost(3.0f) else 1.0f
                val delta = (organicWave + stochasticNoise) * (config.jitterAmplitude * scale)

                finalFps = (baseFps + delta).coerceAtLeast(1.0f)
            }

            // 4. Exact Frame Time: 1000.0 / FPS
            val frameTimeMs = (1000.0f / finalFps).coerceAtLeast(0.05f)

            onUpdateListener?.invoke(finalFps, frameTimeMs, currentlyDropping)

            if (isRunning) {
                val nextDelay = if (config.jitterEnabled) config.jitterSpeedMs.coerceIn(50L, 1000L) else 250L
                handler.postDelayed(this, nextDelay)
            }
        }
    }

    fun start(currentConfig: FpsConfig, listener: (fps: Float, frameTimeMs: Float, isDropping: Boolean) -> Unit) {
        config = currentConfig
        onUpdateListener = listener
        if (isRunning) return
        isRunning = true
        waveStep = Random.nextDouble(0.0, 10.0)
        handler.post(tickerRunnable)
    }

    fun updateConfig(newConfig: FpsConfig) {
        config = newConfig
    }

    fun onRealFpsSample(realFps: Float, realFrameTimeMs: Float, dropRatio: Float) {
        lastRealFps = realFps
        lastRealDropRatio = dropRatio
    }

    fun triggerDrop() {
        dropStartTimeMs = System.currentTimeMillis()
        dropStartTargetFps = config.targetFps
        // Proportional drop floor based on user's target (e.g. 40% of target)
        val floorTarget = (config.targetFps * 0.4f).coerceAtLeast(20f)
        val floorVariance = (Random.nextFloat() * 8f) - 4f
        dropFloorFps = (floorTarget + floorVariance).coerceAtLeast(10f)
        isDroppingActive = true
    }

    fun isDropping(): Boolean = isDroppingActive

    fun stop() {
        isRunning = false
        isDroppingActive = false
        handler.removeCallbacks(tickerRunnable)
    }
}
