package com.example.engine

import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import java.util.ArrayDeque
import kotlin.math.max

/**
 * Real Engine: Measures real screen frame rate via Choreographer frame callbacks.
 * Calculates rolling average FPS, frame time (ms), and tracks the display's baseline refresh rate
 * to compute a dynamic drop ratio for the Fake Engine.
 */
class RealFpsEngine {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isRunning = false

    private var lastFrameTimeNanos: Long = 0L
    private val frameDeltasNs = ArrayDeque<Long>()
    private val frameTimestampsNs = ArrayDeque<Long>()

    var currentRealFps: Float = 60.0f
        private set
    var currentFrameTimeMs: Float = 16.6f
        private set
    var baselineRefreshRate: Float = 60.0f
        private set
    var currentDropRatio: Float = 1.0f
        private set

    private var onUpdateListener: ((fps: Float, frameTimeMs: Float, dropRatio: Float) -> Unit)? = null
    private var lastEmitTimeMs = 0L

    companion object {
        private const val WINDOW_DURATION_NS = 600_000_000L // 600 ms rolling window
        private const val EMIT_INTERVAL_MS = 150L // Responsive 150ms emission
    }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isRunning) return

            if (lastFrameTimeNanos > 0L) {
                val deltaNs = frameTimeNanos - lastFrameTimeNanos

                // Filter out extreme pauses (e.g., screen off or background > 500ms)
                if (deltaNs in 1_000_000L..500_000_000L) {
                    frameDeltasNs.addLast(deltaNs)
                    frameTimestampsNs.addLast(frameTimeNanos)

                    // Prune elements outside rolling window
                    val cutoff = frameTimeNanos - WINDOW_DURATION_NS
                    while (frameTimestampsNs.isNotEmpty() && frameTimestampsNs.first() < cutoff) {
                        frameTimestampsNs.removeFirst()
                        if (frameDeltasNs.isNotEmpty()) {
                            frameDeltasNs.removeFirst()
                        }
                    }

                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastEmitTimeMs >= EMIT_INTERVAL_MS && frameDeltasNs.isNotEmpty()) {
                        lastEmitTimeMs = nowMs

                        // Calculate moving average delta
                        var sumDelta = 0L
                        for (d in frameDeltasNs) {
                            sumDelta += d
                        }
                        val avgDeltaNs = sumDelta.toDouble() / frameDeltasNs.size
                        val measuredFps = (1_000_000_000.0 / avgDeltaNs).toFloat().coerceIn(1.0f, 360.0f)
                        val measuredFrameTimeMs = (avgDeltaNs / 1_000_000.0).toFloat().coerceAtLeast(0.1f)

                        currentRealFps = measuredFps
                        currentFrameTimeMs = measuredFrameTimeMs

                        // Autocalibrate baseline refresh rate (e.g. if device reaches 58-62, baseline is 60; 88-92 -> 90; 118-122 -> 120)
                        if (measuredFps > baselineRefreshRate * 0.95f) {
                            val candidate = when {
                                measuredFps >= 135f -> 144f
                                measuredFps >= 115f -> 120f
                                measuredFps >= 85f -> 90f
                                measuredFps >= 55f -> 60f
                                else -> max(30f, measuredFps)
                            }
                            baselineRefreshRate = max(baselineRefreshRate, candidate)
                        }

                        // Compute dynamic drop ratio
                        currentDropRatio = (measuredFps / baselineRefreshRate).coerceIn(0.05f, 1.05f)

                        onUpdateListener?.invoke(currentRealFps, currentFrameTimeMs, currentDropRatio)
                    }
                }
            }

            lastFrameTimeNanos = frameTimeNanos

            if (isRunning) {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    fun start(listener: ((fps: Float, frameTimeMs: Float, dropRatio: Float) -> Unit)? = null) {
        if (isRunning) {
            listener?.let { onUpdateListener = it }
            return
        }
        isRunning = true
        onUpdateListener = listener
        lastFrameTimeNanos = 0L
        frameDeltasNs.clear()
        frameTimestampsNs.clear()
        lastEmitTimeMs = 0L

        mainHandler.post {
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    fun stop() {
        if (!isRunning) return
        isRunning = false
        mainHandler.post {
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
        frameDeltasNs.clear()
        frameTimestampsNs.clear()
    }
}
