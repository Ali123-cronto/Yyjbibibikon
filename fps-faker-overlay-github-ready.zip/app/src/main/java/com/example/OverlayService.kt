package com.example

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.GestureDetector
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.engine.FakeFpsEngine
import com.example.engine.RealFpsEngine
import com.example.model.FpsConfig
import java.util.Locale
import kotlin.math.abs

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    // UI elements inside overlay
    private var hudRoot: LinearLayout? = null
    private var primaryHudBar: LinearLayout? = null
    private var viewStatusDot: View? = null
    private var tvModeLabel: TextView? = null
    private var tvFpsNumber: TextView? = null
    private var tvFpsUnit: TextView? = null
    private var tvFrameTime: TextView? = null
    private var btnModeSwitch: TextView? = null
    private var layoutQuickMenu: LinearLayout? = null

    // Engines
    private val realFpsEngine = RealFpsEngine()
    private val fakeFpsEngine = FakeFpsEngine()

    private var config: FpsConfig = FpsConfig()
    private var isQuickMenuVisible = false

    private var lastRenderedFps: Float = 0f
    private var lastRenderedMs: Float = 0f

    companion object {
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "fps_faker_channel"

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        config = FpsConfig.load(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Starting FPS Overlay...", 0f, 0f, false))
        initOverlayWindow()
        applyConfigToEngines()
        broadcastStatus()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            FpsConfig.ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            FpsConfig.ACTION_UPDATE_CONFIG -> {
                config = FpsConfig.load(this)
                updateWindowProperties()
                applyConfigToEngines()
                updateHudAppearance()
            }
            FpsConfig.ACTION_TOGGLE_MODE -> {
                toggleMode()
            }
            FpsConfig.ACTION_TRIGGER_DROP -> {
                triggerDrop()
            }
            FpsConfig.ACTION_NEXT_PRESET -> {
                cycleNextPreset()
            }
            FpsConfig.ACTION_TOGGLE_GHOST -> {
                toggleGhostMode()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, fps: Float, ms: Float, isDropping: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Toggle Real/Fake
        val toggleIntent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_TOGGLE_MODE
        }
        val pendingToggle = PendingIntent.getService(
            this, 1, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Simulate Drop
        val dropIntent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_TRIGGER_DROP
        }
        val pendingDrop = PendingIntent.getService(
            this, 2, dropIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Next Hz Preset
        val presetIntent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_NEXT_PRESET
        }
        val pendingPreset = PendingIntent.getService(
            this, 3, presetIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Stop
        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_STOP_OVERLAY
        }
        val pendingStop = PendingIntent.getService(
            this, 4, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val modeTitle = if (config.isFakeMode) "FAKE (${config.targetFps.toInt()}Hz)" else "REAL"
        val subtitle = if (fps > 0) {
            String.format(Locale.US, "FPS: %.1f | Frame: %.1f ms %s", fps, ms, if (isDropping) "⚠️[DROP]" else "")
        } else {
            statusText
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FPS Faker Overlay [$modeTitle]")
            .setContentText(subtitle)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingOpenApp)
            .addAction(R.drawable.hud_chip_background, "⇄ Mode", pendingToggle)
            .addAction(R.drawable.hud_chip_background, "⚡ Drop", pendingDrop)
            .addAction(R.drawable.hud_chip_background, "Next Hz", pendingPreset)
            .addAction(R.drawable.hud_chip_background, "Stop", pendingStop)
            .build()
    }

    private fun updateNotification(fps: Float, ms: Float, isDropping: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification("", fps, ms, isDropping))
    }

    @SuppressLint("InflateParams")
    private fun initOverlayWindow() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_layout, null)
        overlayView = view

        // Bind layout views
        hudRoot = view.findViewById(R.id.hudRoot)
        primaryHudBar = view.findViewById(R.id.primaryHudBar)
        viewStatusDot = view.findViewById(R.id.viewStatusDot)
        tvModeLabel = view.findViewById(R.id.tvModeLabel)
        tvFpsNumber = view.findViewById(R.id.tvFpsNumber)
        tvFpsUnit = view.findViewById(R.id.tvFpsUnit)
        tvFrameTime = view.findViewById(R.id.tvFrameTime)
        btnModeSwitch = view.findViewById(R.id.btnModeSwitch)
        layoutQuickMenu = view.findViewById(R.id.layoutQuickMenu)

        // Setup quick menu preset buttons
        view.findViewById<TextView>(R.id.btnPreset60)?.setOnClickListener { setTargetFps(60f) }
        view.findViewById<TextView>(R.id.btnPreset90)?.setOnClickListener { setTargetFps(90f) }
        view.findViewById<TextView>(R.id.btnPreset120)?.setOnClickListener { setTargetFps(120f) }
        view.findViewById<TextView>(R.id.btnPreset144)?.setOnClickListener { setTargetFps(144f) }
        view.findViewById<TextView>(R.id.btnTriggerDrop)?.setOnClickListener { triggerDrop() }
        view.findViewById<TextView>(R.id.btnCloseHud)?.setOnClickListener {
            toggleQuickMenu()
        }
        btnModeSwitch?.setOnClickListener {
            toggleMode()
        }

        setupWindowLayoutParams()
        setupTouchAndGestures()
        updateHudAppearance()

        try {
            windowManager?.addView(view, windowParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupWindowLayoutParams() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        if (config.isGhostMode) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = config.posX
            y = config.posY
        }
    }

    private fun updateWindowProperties() {
        val params = windowParams ?: return
        val view = overlayView ?: return

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        if (config.isGhostMode) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        params.flags = flags
        try {
            windowManager?.updateViewLayout(view, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchAndGestures() {
        val view = overlayView ?: return
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleMode()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                triggerDrop()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                toggleQuickMenu()
                performHapticFeedback()
            }
        })

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            // Pass event to gesture detector for taps/double taps/long press
            gestureDetector.onTouchEvent(event)

            val params = windowParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()

                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDragging = true
                    }

                    if (isDragging) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        try {
                            windowManager?.updateViewLayout(overlayView, params)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        config = config.copy(posX = params.x, posY = params.y)
                        FpsConfig.save(this, config)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun updateHudAppearance() {
        val root = hudRoot ?: return
        val parsedColor = try {
            Color.parseColor(config.hudColorHex)
        } catch (_: Exception) {
            Color.parseColor("#00E676")
        }

        // Apply alpha
        root.alpha = config.hudOpacity

        // Apply primary neon color
        tvFpsNumber?.setTextColor(parsedColor)

        // Frame time visibility
        tvFrameTime?.visibility = if (config.showFrameTime) View.VISIBLE else View.GONE

        // Update background stroke color
        val bg = root.background as? GradientDrawable
        bg?.setStroke(2, (parsedColor and 0x00FFFFFF) or 0x40000000)
    }

    private fun applyConfigToEngines() {
        fakeFpsEngine.updateConfig(config)

        if (config.isFakeMode) {
            tvModeLabel?.text = "FAKE"
            fakeFpsEngine.start(config) { fps, frameTimeMs, isDropping ->
                renderFps(fps, frameTimeMs, isDropping, isFake = true)
            }
            if (config.syncWithRealFps) {
                realFpsEngine.start { realFps, realFrameTimeMs, dropRatio ->
                    fakeFpsEngine.onRealFpsSample(realFps, realFrameTimeMs, dropRatio)
                }
            } else {
                realFpsEngine.stop()
            }
        } else {
            fakeFpsEngine.stop()
            tvModeLabel?.text = "REAL"
            realFpsEngine.start { fps, frameTimeMs, dropRatio ->
                renderFps(fps, frameTimeMs, isDropping = dropRatio < 0.92f, isFake = false)
            }
        }
    }

    private fun renderFps(fps: Float, frameTimeMs: Float, isDropping: Boolean, isFake: Boolean) {
        lastRenderedFps = fps
        lastRenderedMs = frameTimeMs

        tvFpsNumber?.text = String.format(Locale.US, "%.1f", fps)
        if (config.showFrameTime) {
            tvFrameTime?.text = String.format(Locale.US, "%.1f ms", frameTimeMs)
        }

        // Status indicator dot color
        val dotColor = when {
            isDropping -> Color.parseColor("#FF5252") // Alert Red during drop
            isFake -> try {
                Color.parseColor(config.hudColorHex)
            } catch (_: Exception) {
                Color.parseColor("#00E5FF")
            }
            else -> Color.parseColor("#00E676") // Real engine green
        }
        viewStatusDot?.setBackgroundColor(dotColor)

        // Notification update throttled
        updateNotification(fps, frameTimeMs, isDropping)
    }

    fun toggleMode() {
        performHapticFeedback()
        val newFakeMode = !config.isFakeMode
        config = config.copy(isFakeMode = newFakeMode)
        FpsConfig.save(this, config)
        applyConfigToEngines()
        broadcastStatus()
    }

    fun triggerDrop() {
        performHapticFeedback()
        if (!config.isFakeMode) {
            // If in real mode, switch to fake mode first so drop works as expected
            config = config.copy(isFakeMode = true)
            FpsConfig.save(this, config)
            applyConfigToEngines()
        }
        fakeFpsEngine.triggerDrop()
    }

    fun cycleNextPreset() {
        performHapticFeedback()
        val presets = FpsConfig.AVAILABLE_PRESETS
        val currentIndex = presets.indexOfFirst { it == config.targetFps }
        val nextIndex = if (currentIndex == -1 || currentIndex == presets.lastIndex) 0 else currentIndex + 1
        setTargetFps(presets[nextIndex])
    }

    fun setTargetFps(fps: Float) {
        performHapticFeedback()
        config = config.copy(targetFps = fps, isFakeMode = true)
        FpsConfig.save(this, config)
        applyConfigToEngines()
        broadcastStatus()
    }

    private fun toggleGhostMode() {
        performHapticFeedback()
        config = config.copy(isGhostMode = !config.isGhostMode)
        FpsConfig.save(this, config)
        updateWindowProperties()
    }

    private fun toggleQuickMenu() {
        isQuickMenuVisible = !isQuickMenuVisible
        layoutQuickMenu?.visibility = if (isQuickMenuVisible) View.VISIBLE else View.GONE
    }

    private fun performHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(30)
                }
            }
        } catch (_: Exception) {
            // Vibration not supported or denied
        }
    }

    private fun broadcastStatus() {
        val intent = Intent(FpsConfig.ACTION_SERVICE_STATUS_CHANGED).apply {
            putExtra(FpsConfig.KEY_IS_FAKE_MODE, config.isFakeMode)
            putExtra(FpsConfig.KEY_TARGET_FPS, config.targetFps)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        realFpsEngine.stop()
        fakeFpsEngine.stop()

        overlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        overlayView = null
        broadcastStatus()
    }
}
