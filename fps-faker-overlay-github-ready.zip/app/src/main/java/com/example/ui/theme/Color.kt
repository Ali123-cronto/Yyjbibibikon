package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00E676)
val CyberCyan = Color(0xFF00E5FF)
val ElectricAmber = Color(0xFFFFB300)
val NeonRed = Color(0xFFFF5252)

val DarkCyberBg = Color(0xFF0A0E17)
val DarkCyberSurface = Color(0xFF111827)
val DarkCyberCard = Color(0xFF1A2234)
val DarkCyberBorder = Color(0xFF2E3E5C)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMonospaceGreen = Color(0xFF00FF88)
