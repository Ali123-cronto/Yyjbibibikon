package com.example

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.engine.FakeFpsEngine
import com.example.engine.RealFpsEngine
import com.example.model.FpsConfig
import com.example.ui.theme.DarkCyberBg
import com.example.ui.theme.DarkCyberBorder
import com.example.ui.theme.DarkCyberCard
import com.example.ui.theme.DarkCyberSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var isOverlayServiceRunning by mutableStateOf(false)

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            isOverlayServiceRunning = OverlayService.isRunning
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val filter = IntentFilter(FpsConfig.ACTION_SERVICE_STATUS_CHANGED)
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        setContent {
            MyApplicationTheme(darkTheme = true) {
                FpsFakerApp(
                    isServiceRunning = isOverlayServiceRunning,
                    onStartService = { startOverlayService() },
                    onStopService = { stopOverlayService() },
                    onConfigUpdated = { notifyConfigUpdated() },
                    onTriggerDrop = { sendDropCommand() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isOverlayServiceRunning = OverlayService.isRunning
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(statusReceiver)
        } catch (_: Exception) {}
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_START_OVERLAY
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        isOverlayServiceRunning = true
    }

    private fun stopOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = FpsConfig.ACTION_STOP_OVERLAY
        }
        startService(intent)
        isOverlayServiceRunning = false
    }

    private fun notifyConfigUpdated() {
        if (OverlayService.isRunning) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = FpsConfig.ACTION_UPDATE_CONFIG
            }
            startService(intent)
        }
    }

    private fun sendDropCommand() {
        if (OverlayService.isRunning) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = FpsConfig.ACTION_TRIGGER_DROP
            }
            startService(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FpsFakerApp(
    isServiceRunning: Boolean,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onConfigUpdated: () -> Unit,
    onTriggerDrop: () -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    var config by remember { mutableStateOf(FpsConfig.load(context)) }

    // Custom Target FPS text input state (without restrictions)
    var customFpsInput by remember(config.targetFps) {
        mutableStateOf(
            if (config.targetFps % 1f == 0f) config.targetFps.toInt().toString()
            else String.format(Locale.US, "%.1f", config.targetFps)
        )
    }

    // Overlay Permission check
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }

    // Recheck permission on lifecycle resume
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Notification permission request for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Live preview engine for the in-app interactive HUD preview
    var previewFps by remember { mutableFloatStateOf(config.targetFps) }
    var previewMs by remember { mutableFloatStateOf(1000f / config.targetFps) }
    var isPreviewDropping by remember { mutableStateOf(false) }

    // Real screen FPS metrics for live preview & monitoring
    var currentRealMeasuredFps by remember { mutableFloatStateOf(60f) }
    var currentRealDropRatio by remember { mutableFloatStateOf(1f) }
    var detectedBaselineHz by remember { mutableFloatStateOf(60f) }

    val previewEngine = remember { FakeFpsEngine() }
    val realMonitor = remember { RealFpsEngine() }

    // Start Real Monitor for live sync calculation
    DisposableEffect(Unit) {
        realMonitor.start { fps, _, ratio ->
            currentRealMeasuredFps = fps
            currentRealDropRatio = ratio
            detectedBaselineHz = realMonitor.baselineRefreshRate
            previewEngine.onRealFpsSample(fps, 1000f / fps, ratio)
        }
        onDispose {
            realMonitor.stop()
        }
    }

    LaunchedEffect(config) {
        previewEngine.start(config) { fps, ms, dropping ->
            previewFps = fps
            previewMs = ms
            isPreviewDropping = dropping
        }
    }

    fun updateConfigAndSave(newConfig: FpsConfig) {
        config = newConfig
        FpsConfig.save(context, newConfig)
        previewEngine.updateConfig(newConfig)
        onConfigUpdated()
    }

    fun applyCustomFpsText(input: String) {
        customFpsInput = input
        val cleanValue = input.replace(',', '.').toFloatOrNull()
        if (cleanValue != null && cleanValue > 0f) {
            updateConfigAndSave(config.copy(targetFps = cleanValue))
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "FPS Faker Overlay",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = if (config.isFakeMode) {
                                    if (config.syncWithRealFps) "Fake (${config.targetFps.toInt()} FPS) • Real Sync ON"
                                    else "Fake (${config.targetFps.toInt()} FPS) • Fixed"
                                } else "Real Engine Active",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (config.isFakeMode) Color(0xFF00E5FF) else NeonGreen
                            )
                        }
                    }
                },
                actions = {
                    FilterChip(
                        selected = config.isFakeMode,
                        onClick = {
                            updateConfigAndSave(config.copy(isFakeMode = !config.isFakeMode))
                        },
                        label = {
                            Text(
                                text = if (config.isFakeMode) "FAKE" else "REAL",
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00E5FF).copy(alpha = 0.2f),
                            selectedLabelColor = Color(0xFF00E5FF),
                            labelColor = NeonGreen
                        ),
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkCyberSurface
                )
            )
        },
        containerColor = DarkCyberBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // 1. Permission Warning Card (if needed)
            if (!hasOverlayPermission) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2D1619)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NeonRed)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("permission_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = NeonRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Overlay Permission Required",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "To draw the floating FPS counter above your games, grant the 'Display over other apps' system permission.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                            modifier = Modifier.fillMaxWidth().testTag("grant_permission_button")
                        ) {
                            Text("Grant Permission", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            // 2. Primary Service Launch Banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isServiceRunning) Color(0xFF0F291E) else DarkCyberCard
                ),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(
                        if (isServiceRunning) NeonGreen else DarkCyberBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isServiceRunning) NeonGreen else Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isServiceRunning) "Overlay Active" else "Overlay Inactive",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isServiceRunning) NeonGreen else TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isServiceRunning)
                                "Visible on top of apps & games"
                            else
                                "Tap button to show floating HUD",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = {
                            if (isServiceRunning) {
                                onStopService()
                            } else {
                                if (hasOverlayPermission) {
                                    onStartService()
                                } else {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isServiceRunning) NeonRed else NeonGreen
                        ),
                        modifier = Modifier.testTag("toggle_service_button")
                    ) {
                        Icon(
                            imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isServiceRunning) "Stop" else "Start",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }

            // 3. Interactive Live Simulation Preview Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Live HUD Preview",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        // Test Drop button
                        OutlinedButton(
                            onClick = {
                                previewEngine.triggerDrop()
                                onTriggerDrop()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = NeonRed
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = androidx.compose.ui.graphics.SolidColor(NeonRed)
                            ),
                            modifier = Modifier.height(36.dp).testTag("preview_drop_button")
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Drop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val hudColor = try {
                        Color(android.graphics.Color.parseColor(config.hudColorHex))
                    } catch (_: Exception) {
                        NeonGreen
                    }

                    // Floating HUD badge mockup
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(88.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF060911)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0D1117).copy(alpha = config.hudOpacity))
                                .border(1.dp, hudColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            // Status Dot
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isPreviewDropping) NeonRed else hudColor
                                    )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (config.isFakeMode) "FAKE" else "REAL",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format(Locale.US, "%.1f", previewFps),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = hudColor
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "FPS",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            if (config.showFrameTime) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = String.format(Locale.US, "%.1f ms", previewMs),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isPreviewDropping) "⚠️ Frame drop active: Fake counter dips in sync with real performance!"
                        else if (config.syncWithRealFps) "Dynamic Sync: Real screen FPS (${String.format(Locale.US, "%.1f", currentRealMeasuredFps)}) actively drives fake drops."
                        else "Preview reflects user-specified value and micro-jitter noise.",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPreviewDropping) NeonRed else TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 4. Custom Target FPS Input (WITHOUT RESTRICTIONS)
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NeonGreen.copy(alpha = 0.6f))),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Custom Fake FPS (Без ограничений)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Введите абсолютно любое желаемое число кадров: 120, 240, 360, 500, 999, 1000 и выше. Любые ограничения сняты.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Direct Numeric Input Field
                    OutlinedTextField(
                        value = customFpsInput,
                        onValueChange = { newValue ->
                            // Allow digits and single decimal dot
                            val filtered = newValue.filter { it.isDigit() || it == '.' || it == ',' }
                            applyCustomFpsText(filtered)
                        },
                        label = { Text("Целевой Fake FPS (введите число)") },
                        trailingIcon = {
                            Text(
                                text = "FPS",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { focusManager.clearFocus() }
                        ),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = DarkCyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = NeonGreen
                        ),
                        textStyle = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("custom_fps_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Fast Quick-Fill Preset Buttons
                    Text(
                        text = "Быстрые шаблоны (нажмите для вставки):",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val quickPresets = listOf(60f, 90f, 120f, 144f, 165f, 240f, 360f, 500f, 999f)
                        quickPresets.forEach { presetFps ->
                            val isSelected = config.targetFps == presetFps
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    applyCustomFpsText(presetFps.toInt().toString())
                                    focusManager.clearFocus()
                                },
                                label = {
                                    Text(
                                        text = "${presetFps.toInt()}",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonGreen.copy(alpha = 0.25f),
                                    selectedLabelColor = NeonGreen,
                                    labelColor = TextPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Step Adjustment Buttons (-10, -1, +1, +10, +50)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(-50, -10, -1, 1, 10, 50).forEach { delta ->
                            OutlinedButton(
                                onClick = {
                                    val current = config.targetFps
                                    val updated = (current + delta).coerceAtLeast(1f)
                                    applyCustomFpsText(updated.toInt().toString())
                                },
                                modifier = Modifier.weight(1f).height(34.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (delta > 0) NeonGreen else TextSecondary
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)
                                )
                            ) {
                                Text(
                                    text = if (delta > 0) "+$delta" else "$delta",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // 5. Связь с настоящим FPS (Синхронизация просадок)
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(
                        if (config.syncWithRealFps) Color(0xFF00E5FF) else DarkCyberBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Связь с реальным FPS",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Фейк проседает синхронно с реальным экраном",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }
                        Switch(
                            checked = config.syncWithRealFps,
                            onCheckedChange = { sync ->
                                updateConfigAndSave(config.copy(syncWithRealFps = sync))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00E5FF),
                                checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.35f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Когда в игре или приложении падает реальный FPS экрана, фейковый счетчик пропорционально проседает вместе с ним в реальном времени! На видео и скриншотах просадки выглядят 100% натурально.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Telemetry status block
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0B132B))
                            .border(1.dp, Color(0xFF1C2541), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Реальный FPS экрана:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = String.format(Locale.US, "%.1f FPS / %.0f Hz", currentRealMeasuredFps, detectedBaselineHz),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = NeonGreen
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Статус нагрузки экрана:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                val dropPercent = ((1.0f - currentRealDropRatio) * 100f).coerceAtLeast(0f)
                                Text(
                                    text = if (dropPercent > 5f) "⚠️ Просадка: -${dropPercent.toInt()}%" else "✓ Стабильно (100%)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (dropPercent > 5f) NeonRed else NeonGreen
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Динамический Fake FPS:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                val dynamicBase = config.targetFps * (1.0f - (1.0f - currentRealDropRatio) * config.realDropSensitivity).coerceIn(0.1f, 1.0f)
                                Text(
                                    text = String.format(Locale.US, "%.1f FPS", dynamicBase),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sensitivity Slider
                    Text(
                        text = "Чувствительность к просадкам: ${String.format(Locale.US, "%.1fx", config.realDropSensitivity)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Slider(
                        value = config.realDropSensitivity,
                        onValueChange = { sens ->
                            updateConfigAndSave(config.copy(realDropSensitivity = (sens * 10).toInt() / 10f))
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 14,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = DarkCyberBorder
                        )
                    )
                }
            }

            // 6. Micro-fluctuations ("Дрожание цифры")
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Micro-Fluctuations (Дрожание цифры)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Органический шум, чтобы цифра естественно колебалась (например: 119.4 -> 120.1 -> 118.9)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = config.jitterEnabled,
                            onCheckedChange = { enabled ->
                                updateConfigAndSave(config.copy(jitterEnabled = enabled))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NeonGreen,
                                checkedTrackColor = NeonGreen.copy(alpha = 0.35f)
                            )
                        )
                    }

                    AnimatedVisibility(visible = config.jitterEnabled) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Text(
                                text = "Амплитуда колебаний: ±${String.format(Locale.US, "%.1f", config.jitterAmplitude)} FPS",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Slider(
                                value = config.jitterAmplitude,
                                onValueChange = { amp ->
                                    updateConfigAndSave(config.copy(jitterAmplitude = (amp * 10).toInt() / 10f))
                                },
                                valueRange = 0.2f..4.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonGreen,
                                    activeTrackColor = NeonGreen,
                                    inactiveTrackColor = DarkCyberBorder
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Частота обновления шума: ${config.jitterSpeedMs} ms",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Slider(
                                value = config.jitterSpeedMs.toFloat(),
                                onValueChange = { ms ->
                                    updateConfigAndSave(config.copy(jitterSpeedMs = ms.toLong()))
                                },
                                valueRange = 100f..500f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonGreen,
                                    activeTrackColor = NeonGreen,
                                    inactiveTrackColor = DarkCyberBorder
                                )
                            )
                        }
                    }
                }
            }

            // 7. Manual Drop / Freeze Simulation
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Ручной триггер просадки (Drop Simulation)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Симулирует секундную просадку с плавным восстановлением (также активируется двойным тапом по оверлею).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            previewEngine.triggerDrop()
                            onTriggerDrop()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.85f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ссимулировать дроп FPS сейчас (⚡)", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            // 8. Frame Time & Ghost Mode Settings
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Индикатор Frame Time (ms)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Математический расчет: 1000.0 / FPS",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = config.showFrameTime,
                            onCheckedChange = { show ->
                                updateConfigAndSave(config.copy(showFrameTime = show))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00E5FF),
                                checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.35f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Режим «Призрак» (Click-Through)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Клики проходят сквозь оверлей в игру (управление через шторку)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = config.isGhostMode,
                            onCheckedChange = { ghost ->
                                updateConfigAndSave(config.copy(isGhostMode = ghost))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFFFFB300),
                                checkedTrackColor = Color(0xFFFFB300).copy(alpha = 0.35f)
                            )
                        )
                    }
                }
            }

            // 9. HUD Appearance & Colors
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Внешний вид и стиль HUD",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Цвет счетчика:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FpsConfig.COLOR_PRESETS.forEach { (hex, name) ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = config.hudColorHex.equals(hex, ignoreCase = true)

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        updateConfigAndSave(config.copy(hudColorHex = hex))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = name,
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Прозрачность подложки: ${(config.hudOpacity * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Slider(
                        value = config.hudOpacity,
                        onValueChange = { op ->
                            updateConfigAndSave(config.copy(hudOpacity = (op * 100).toInt() / 100f))
                        },
                        valueRange = 0.15f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonGreen,
                            activeTrackColor = NeonGreen,
                            inactiveTrackColor = DarkCyberBorder
                        )
                    )
                }
            }

            // 10. Gesture Guide
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCyberSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCyberBorder)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Быстрые жесты оверлея",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    GestureGuideItem(title = "Перетаскивание (Drag)", desc = "Свободное перемещение бейджа пальцем в любую точку экрана с автосохранением.")
                    GestureGuideItem(title = "Одиночный тап", desc = "Мгновенное незаметное переключение Real <-> Fake.")
                    GestureGuideItem(title = "Двойной тап", desc = "Имитация дропа/фриза с плавным выходом на целевой FPS.")
                    GestureGuideItem(title = "Долгое нажатие", desc = "Раскрытие компактной панели быстрого переключения в самом бейдже.")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun GestureGuideItem(title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "•",
            color = NeonGreen,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(end = 8.dp)
        )
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}
