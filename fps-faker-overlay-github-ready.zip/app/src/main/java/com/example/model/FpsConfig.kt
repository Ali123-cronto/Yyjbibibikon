package com.example.model

import android.content.Context
import android.content.SharedPreferences

data class FpsConfig(
    val isFakeMode: Boolean = true,
    val targetFps: Float = 120.0f,
    val syncWithRealFps: Boolean = true, // Fake FPS drops in lockstep when Real FPS drops
    val realDropSensitivity: Float = 1.0f, // 0.5x to 2.0x drop intensity
    val jitterEnabled: Boolean = true,
    val jitterAmplitude: Float = 1.2f, // +/- range
    val jitterSpeedMs: Long = 220L,
    val dropTargetFps: Float = 48.0f,
    val dropDurationMs: Long = 1800L,
    val showFrameTime: Boolean = true,
    val hudOpacity: Float = 0.88f,
    val hudColorHex: String = "#00E676",
    val isGhostMode: Boolean = false,
    val posX: Int = 100,
    val posY: Int = 180
) {
    companion object {
        const val PREFS_NAME = "fps_faker_prefs"

        const val KEY_IS_FAKE_MODE = "is_fake_mode"
        const val KEY_TARGET_FPS = "target_fps"
        const val KEY_SYNC_WITH_REAL_FPS = "sync_with_real_fps"
        const val KEY_REAL_DROP_SENSITIVITY = "real_drop_sensitivity"
        const val KEY_JITTER_ENABLED = "jitter_enabled"
        const val KEY_JITTER_AMPLITUDE = "jitter_amplitude"
        const val KEY_JITTER_SPEED_MS = "jitter_speed_ms"
        const val KEY_DROP_TARGET_FPS = "drop_target_fps"
        const val KEY_DROP_DURATION_MS = "drop_duration_ms"
        const val KEY_SHOW_FRAME_TIME = "show_frame_time"
        const val KEY_HUD_OPACITY = "hud_opacity"
        const val KEY_HUD_COLOR_HEX = "hud_color_hex"
        const val KEY_IS_GHOST_MODE = "is_ghost_mode"
        const val KEY_POS_X = "pos_x"
        const val KEY_POS_Y = "pos_y"

        // Intent Actions
        const val ACTION_START_OVERLAY = "com.example.ACTION_START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.example.ACTION_STOP_OVERLAY"
        const val ACTION_UPDATE_CONFIG = "com.example.ACTION_UPDATE_CONFIG"
        const val ACTION_TOGGLE_MODE = "com.example.ACTION_TOGGLE_MODE"
        const val ACTION_TRIGGER_DROP = "com.example.ACTION_TRIGGER_DROP"
        const val ACTION_NEXT_PRESET = "com.example.ACTION_NEXT_PRESET"
        const val ACTION_TOGGLE_GHOST = "com.example.ACTION_TOGGLE_GHOST"
        const val ACTION_SERVICE_STATUS_CHANGED = "com.example.ACTION_SERVICE_STATUS_CHANGED"

        val AVAILABLE_PRESETS = listOf(60f, 90f, 120f, 144f, 165f, 240f, 360f, 500f, 999f)

        val COLOR_PRESETS = listOf(
            "#00E676" to "MSI Neon Green",
            "#00E5FF" to "Cyberpunk Cyan",
            "#FFB300" to "Game Turbo Amber",
            "#FF1744" to "Nitro Red",
            "#E040FB" to "Razer Magenta"
        )

        fun load(context: Context): FpsConfig {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return FpsConfig(
                isFakeMode = prefs.getBoolean(KEY_IS_FAKE_MODE, true),
                targetFps = prefs.getFloat(KEY_TARGET_FPS, 120.0f),
                syncWithRealFps = prefs.getBoolean(KEY_SYNC_WITH_REAL_FPS, true),
                realDropSensitivity = prefs.getFloat(KEY_REAL_DROP_SENSITIVITY, 1.0f),
                jitterEnabled = prefs.getBoolean(KEY_JITTER_ENABLED, true),
                jitterAmplitude = prefs.getFloat(KEY_JITTER_AMPLITUDE, 1.2f),
                jitterSpeedMs = prefs.getLong(KEY_JITTER_SPEED_MS, 220L),
                dropTargetFps = prefs.getFloat(KEY_DROP_TARGET_FPS, 48.0f),
                dropDurationMs = prefs.getLong(KEY_DROP_DURATION_MS, 1800L),
                showFrameTime = prefs.getBoolean(KEY_SHOW_FRAME_TIME, true),
                hudOpacity = prefs.getFloat(KEY_HUD_OPACITY, 0.88f),
                hudColorHex = prefs.getString(KEY_HUD_COLOR_HEX, "#00E676") ?: "#00E676",
                isGhostMode = prefs.getBoolean(KEY_IS_GHOST_MODE, false),
                posX = prefs.getInt(KEY_POS_X, 100),
                posY = prefs.getInt(KEY_POS_Y, 180)
            )
        }

        fun save(context: Context, config: FpsConfig) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().apply {
                putBoolean(KEY_IS_FAKE_MODE, config.isFakeMode)
                putFloat(KEY_TARGET_FPS, config.targetFps)
                putBoolean(KEY_SYNC_WITH_REAL_FPS, config.syncWithRealFps)
                putFloat(KEY_REAL_DROP_SENSITIVITY, config.realDropSensitivity)
                putBoolean(KEY_JITTER_ENABLED, config.jitterEnabled)
                putFloat(KEY_JITTER_AMPLITUDE, config.jitterAmplitude)
                putLong(KEY_JITTER_SPEED_MS, config.jitterSpeedMs)
                putFloat(KEY_DROP_TARGET_FPS, config.dropTargetFps)
                putLong(KEY_DROP_DURATION_MS, config.dropDurationMs)
                putBoolean(KEY_SHOW_FRAME_TIME, config.showFrameTime)
                putFloat(KEY_HUD_OPACITY, config.hudOpacity)
                putString(KEY_HUD_COLOR_HEX, config.hudColorHex)
                putBoolean(KEY_IS_GHOST_MODE, config.isGhostMode)
                putInt(KEY_POS_X, config.posX)
                putInt(KEY_POS_Y, config.posY)
                apply()
            }
        }
    }
}
